from setuptools import setup, find_packages

setup(
    name='GettingStartedWithPyramid',
    version='',
    url='',
    license='',
    author='aakritimalla',
    author_email='',
    description='',
    install_requires=[
        'pyramid',
        'pymongo',
        'waitress',

    ],
    packages=find_packages(),
    include_package_data=True,
    entry_points={
        'paste.app_factory': [
            'main = GettingStartedWithPyramid:main'
        ],
    },
)
